
class HomeEvent {
  var clicked;
  HomeEvent(this.clicked);
}
