
class HomeState{
bool response;
HomeState(this.response);
}