
import 'package:equatable/equatable.dart';

abstract class Courses_Event extends Equatable {
  @override
  List<Object> get props => [];
}
class courselistFetched extends Courses_Event {}

