class ThemeChangeEvent {
  String colorStr;
  ThemeChangeEvent(this.colorStr);
}