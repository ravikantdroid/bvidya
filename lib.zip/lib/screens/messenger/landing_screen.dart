import 'package:agora_rtm/agora_rtm.dart';
import 'package:evidya/screens/messenger/group/group_chat_screen.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../constants/string_constant.dart';
import '../../localdb/databasehelper.dart';
import '../../model/GroupListModal.dart';
import '../../model/recentchatconnectionslist_modal.dart';
import '../../network/repository/api_repository.dart';
import '../../sharedpref/preference_connector.dart';
import '../../widget/gradient_bg_view.dart';
import '../bottom_navigation/bottom_navigaction_bar.dart';
import 'chat_screen.dart';
// import 'logs.dart';

class LandingScreen extends StatefulWidget {
  final String peerId;
  final bool isGroup;
  const LandingScreen({Key key, this.peerId, this.isGroup}) : super(key: key);

  @override
  State<LandingScreen> createState() => _LandingScreenState();
}

class _LandingScreenState extends State<LandingScreen> {
  int _loading = 0;
  Connections _user;
  List<Connections> _users = [];
  AgoraRtmClient _client;
  Groups _group;
  bool _hasBuildCalled = false;

  @override
  void initState() {
    super.initState();
    _openChatScreen(widget.peerId, widget.isGroup);
  }

  @override
  void dispose() {
    _client?.logout();
    _client?.destroy();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _hasBuildCalled = true;
    return WillPopScope(
      onWillPop: () {
        return Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
                builder: (context) => const BottomNavbar(index: 2)),
            (Route<dynamic> route) => false);
      },
      child: _loading == 0
          ? const Scaffold(
              body: GradientColorBgView(
              child: Center(
                child: CircularProgressIndicator(),
              ),
            ))
          : _loading == 3 && _group != null
              ? GroupChatScreen(
                  client: _client,
                  rtmpeerid: _group.members[0].pid,
                  membersList: _group.members,
                  recentchatuserdetails: _group,
                  self: _group.self,
                  isDirect: true,
                )
              : _loading == 2
                  ? Chat_Screen(
                      client: _client,
                      rtmpeerid: widget.peerId,
                      recentchatuserdetails: _user,
                      status: _user.status,
                      userlist: _users,
                    )
                  : const Scaffold(
                      body: Center(
                        child: Text('No chat found'),
                      ),
                    ),
    );
  }

  _openChatScreen(String peerId, bool isGroup) async {
    debugPrint('opening chat screen items');
    const String appId = "d6306b59624c4e458883be16f5e6cbd2";
    _client = await AgoraRtmClient.createInstance(appId);
    try {
      final value = await PreferenceConnector.getJsonToSharedPreferencetoken(
          StringConstant.loginData);
      final result = await ApiRepository().Messanger_rtmtoken(value);
      if (result != null && result.status == "successfull") {
        await _client.login(result.body.rtmToken, result.body.rtmUser);
        final dbHelper = DatabaseHelper.instance;
        if (isGroup) {
          final prefs = await SharedPreferences.getInstance();
          await prefs.setBool('groupbadge', false);
          List<Groups> _groups = await dbHelper.getAllgroupdata();
          Groups selectedGroup =
              _groups.where((row) => row.groupName == peerId)?.first;
          if (selectedGroup == null) {
            final list = await ApiRepository().groupList(value);
            if (list != null) {
              _groups = list.body.groups;
              selectedGroup =
                  _groups.where((row) => row.groupName == peerId)?.first;
            }
          } else {
            debugPrint('Found group: ${selectedGroup.toJson()}');
          }
          if (selectedGroup != null) {
            _group = selectedGroup;
            _loading = 3;
            if (_hasBuildCalled) {
              setState(() {});
            }
            return;
          }
          _loading = 1;
          if (_hasBuildCalled) {
            setState(() {});
          }
          return;
        } else {
          _users = await dbHelper.getAlldata();
          Connections selectedUser =
              _users.where((row) => row.peerId == peerId).first;
          if (selectedUser == null) {
            final value2 = await ApiRepository().recentconnection(value);
            if (value2 != null && value2.status == 'successfull') {
              _users = value2.body.connections;
              selectedUser = _users.where((row) => row.peerId == peerId)?.first;
            }
          }
          if (selectedUser != null) {
            _user = selectedUser;
            _loading = 2;
            if (_hasBuildCalled) {
              setState(() {});
            }
            return;
          }
        }
      }
    } catch (errorCode) {
      debugPrint('Login error: ' + errorCode.toString());
    }
    _loading = 1;
  }

  // _openGroupChatScreen(String groupName) async {
  //   debugPrint('opening chat screen items');
  //   const String appId = "d6306b59624c4e458883be16f5e6cbd2";
  //   _client = await AgoraRtmClient.createInstance(appId);
  //   try {
  //     final value = await PreferenceConnector.getJsonToSharedPreferencetoken(
  //         StringConstant.loginData);
  //     final list = await ApiRepository().groupList(value);
  //     if (list != null) {
  //       List<Groups> _groups = list.body.groups;
  //       final selectedGroup =
  //           _groups.where((row) => row.groupName == groupName)?.first;
  //       if (selectedGroup != null) {
  //         _group = selectedGroup;
  //         _loading = 3;
  //         if (_hasBuildCalled) {
  //           setState(() {});
  //         }
  //         return;
  //       }
  //     }
  //   } catch (errorCode) {
  //     debugPrint('Login error: ' + errorCode.toString());
  //   }
  //   _loading = 1;
  // }
}
