// import 'dart:async';

// import 'package:firebase_core/firebase_core.dart';
// import 'package:firebase_messaging/firebase_messaging.dart';


// Future<void> onBackgroundMessage(RemoteMessage message) async {
//   await Firebase.initializeApp();

//   if (message.data.containsKey('data')) {
//     // Handle data message
//     final data = message.data['data'];
//     debugPrint('Notificationsdata:$data');
//   }

//   if (message.data.containsKey('notification')) {
//     // Handle notification message
//     final notification = message.data['notification'];
//     debugPrint('notification:$notification');
//   }
//   // Or do other work.


//   // the call received somewhere
// }

// class FCM {
//   final _firebaseMessaging = FirebaseMessaging.instance;

//   final streamCtlr = StreamController<String>.broadcast();
//   final titleCtlr = StreamController<String>.broadcast();
//   final bodyCtlr = StreamController<String>.broadcast();





//   setNotifications() {
//     FirebaseMessaging.onBackgroundMessage(onBackgroundMessage);
//     FirebaseMessaging.onMessage.listen(
//           (message) async {
//         if (message.data.containsKey('data')) {
//           // Handle data message
//           streamCtlr.sink.add(message.data['data']);
//         }
//         if (message.data.containsKey('notification')) {
//           // Handle notification message
//           streamCtlr.sink.add(message.data['notification']);
//         }
//         // Or do other work.
//         titleCtlr.sink.add(message.notification.title);
//         bodyCtlr.sink.add(message.notification.body);
//       },
//     );
//     // With this token you can test it easily on your phone
//     final token = _firebaseMessaging.getToken().then((value) => debugPrint('NotificationsToken: $value'));


//   }

//   dispose() {
//     streamCtlr.close();
//     bodyCtlr.close();
//     titleCtlr.close();
//   }
// }