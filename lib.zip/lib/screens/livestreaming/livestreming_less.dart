import 'package:flutter/material.dart';

import 'live_stremaing_screen.dart';

class LiveStreamingLess extends StatelessWidget {
  const LiveStreamingLess({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home:Scaffold(
        appBar: AppBar(title: Text("sdsd"),),
        body:  Text('dsd'),
      ),
    );

  }
}
