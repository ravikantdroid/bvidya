import 'package:evidya/model/meet_list__modal.dart';

class Schudlemeet_State{
  bool isLoginSuccess=false;
  //IS DATA RETERIVE

  String usermsg,passwordmsg,response;
  Schudlemeet_State(this.isLoginSuccess,this.usermsg,this.passwordmsg,this.response);
}