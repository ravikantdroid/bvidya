class Schudlemeet_Event{
  String title, subject,date,time;
  Schudlemeet_Event(this.title,this.subject,this.date,this.time);
}