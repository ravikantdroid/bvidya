class ProfileConstant {
  static const String LETTER = "Letter";
  static const String SERVER = "Server";
  static const String File = "File";
}
