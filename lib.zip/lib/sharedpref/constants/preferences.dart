class Preferences {
  Preferences._();

  static const String is_logged_in = "isLoggedIn";
}
