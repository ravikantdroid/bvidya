// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'result.dart';

Result _$ResultFromJson(Map<String, dynamic> json) {
  return Result(
    accessToken: json['accessToken'] as String,
    tokenType: json['tokenType'] as String,
    expiresIn: json['expiresIn'] as int,
    data: json['data'] == null
        ? null
        : Data.fromJson(json['data'] as Map<String, dynamic>),
  );
}

Map<String, dynamic> _$ResultToJson(Result instance) => <String, dynamic>{
      'accessToken': instance.accessToken,
      'tokenType': instance.tokenType,
      'expiresIn': instance.expiresIn,
      'data': instance.data,
    };
