class RegistrationUserDetails {
  String userEmail;
  String password;
  String firstName;
  String lastName;
  String phoneNo;
}